<?php
header("Location: /index.php?s=Adminx/Index/index");
?>