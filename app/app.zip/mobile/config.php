<?php
return [
	//模板布局
    'template' => [
        'layout_on' => true,
        'layout_name' => 'layout',
    ],
    'dispatch_error_tmpl'    => 'public:jump',
];