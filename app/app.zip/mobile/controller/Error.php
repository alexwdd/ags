<?php
namespace app\www\controller;

class Error extends Home{
    public function index(){
        
    }
}
