<?php
namespace app\common\model;

use think\Model;

class Common extends Model
{
	
}